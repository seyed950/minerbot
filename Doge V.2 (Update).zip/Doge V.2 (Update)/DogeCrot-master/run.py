#!/bin/usr/python2
#Mau Recode Ya Bangsat?
#Dasar Otak Udang!
import os
import sys
os.system('clear')
print ('\n\n')
print ('\033[1;96m ╦ ╦╔═╗╦  ╔═╗╔═╗╔╦╗╔═╗  ╦ ╦╔═╗╔═╗╦═╗')
print (' ║║║║╣ ║  ║  ║ ║║║║║╣   ║ ║╚═╗║╣ ╠╦╝')
print (' ╚╩╝╚═╝╩═╝╚═╝╚═╝╩ ╩╚═╝  ╚═╝╚═╝╚═╝╩╚═')
print ('\033[0;90m    [\033[1;36m+\033[0;90m] Enter your phone_number')
print ('\033[0;90m    [\033[1;36m+\033[0;90m] Example: +6283195766895')
doge = input('\033[0;90m    [\033[1;36m+\033[0;90m] Your Number: \033[1;36m')
os.system('cd .core && python main.py ' + doge)
